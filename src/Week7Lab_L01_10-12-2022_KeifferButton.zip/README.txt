All the files should run properly if you run them individually.

For ExtraProblem4 I decided to make art that randomly generates each time, but because of this it may take a long time to launch.
So if it doesn't launch right away just be patient!